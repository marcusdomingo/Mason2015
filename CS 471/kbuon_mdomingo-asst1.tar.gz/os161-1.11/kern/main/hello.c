#include <types.h>
#include <lib.h>
#include <test.h>

void hello(void)
{
	DEBUG(DB_EXEC, "Executed properly\n");
	kprintf("Hello World\n");
}
