/* 
 * stoplight.c
 *
 * 31-1-2003 : GWA : Stub functions created for CS161 Asst1.
 *
 * NB: You can use any synchronization primitives available to solve
 * the stoplight problem in this file.
 */


/*
 * 
 * Includes
 *
 */

#include <types.h>
#include <lib.h>
#include <test.h>
#include <thread.h>
#include <synch.h> 

/*
 *
 * Constants
 *
 */ 

/*
 * Number of cars created.
 */

#define NCARS 20


/*
 * keep count of the threads 
 */

static int count;

/*
 * menu lock to stop prog from jumping to the boot menu
 * control lock to control the flow of traffic through the intersection
 * the rest are intersection locks used for the specs
 */

static struct lock *menulock;
static struct lock *control;
static struct lock *NtoW;
static struct lock *NtoS;
static struct lock *NtoE;
static struct lock *EtoN;
static struct lock *EtoW;
static struct lock *EtoS;
static struct lock *StoE;
static struct lock *StoN;
static struct lock *StoW;
static struct lock *WtoS;
static struct lock *WtoE;
static struct lock *WtoN;
static struct lock *NW;
static struct lock *NE;
static struct lock *SE;
static struct lock *SW;

/*
 *
 *Function Definitions
 *
 */

/*
 * create all the locks
 */
void stoplight_init()
{
	control = lock_create("control");
	NtoW = lock_create("NtoW");
	NtoS = lock_create("NtoS");
	NtoE = lock_create("NtoE");
	EtoN = lock_create("EtoN");
	EtoW = lock_create("EtoW");
	EtoS = lock_create("EtoS");
	StoE = lock_create("StoE");
	StoN = lock_create("StoN");
	StoW = lock_create("StoW");
	WtoS = lock_create("WtoS");
	WtoE = lock_create("WtoE");
	WtoN = lock_create("WtoN");
	NW = lock_create("quad 0");
	NE = lock_create("quad 1");
	SE = lock_create("quad 2");
	SW = lock_create("quad 3");

}

/*
 * destroy all the locks
 */
void stoplight_cleanup()
{
	lock_destroy(control);
	lock_destroy(NtoW);
	lock_destroy(NtoS);
	lock_destroy(NtoE);
	lock_destroy(EtoN);
	lock_destroy(EtoW);
	lock_destroy(EtoS);
	lock_destroy(StoE);
	lock_destroy(StoN);
	lock_destroy(StoW);
	lock_destroy(WtoS);
	lock_destroy(WtoE);
	lock_destroy(WtoN);
	lock_destroy(NW);
	lock_destroy(NE);
	lock_destroy(SE);
	lock_destroy(SW);
}

/*
 * 0 = North, 1 = East, 2 = South, 3 = West
 */
static const char *direction[] = {"N", "E", "S", "W"};

/*
 * gostraight()
 *
 * Arguments:
 *      unsigned long cardirection: the direction from which the car
 *              approaches the intersection.
 *      unsigned long carnumber: the car id number for printing purposes.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      This function should implement passing straight through the
 *      intersection from any direction.
 *      Write and comment this function.
 */

static
void
gostraight(unsigned long cardirection,
           unsigned long carnumber,
	   unsigned long turndestination)
{
        /*
         * Avoid unused variable warnings.
         */
        
        (void) cardirection;
        (void) carnumber;
	
	// controls the flow of the traffic
	lock_acquire(control);

	/*
	 * Switch Case:
	 * 	case is chosen based on direction the car is coming from.
	 *
	 * Purpose:
	 * 	go straight through the intersection and print statements when
	 * 	in the specific quadrant or leaving. locks on the quadrants and
	 * 	the direction that the car is coming from so another car can't
	 * 	travel straight at the same time from the same direction.
	 */
	switch(cardirection)
	{
		case 0:
			lock_acquire(NtoS);
			lock_acquire(NW);
			//lock_acquire(SW);
			kprintf("ENTERING->NW, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_acquire(SW);
			kprintf("ENTERING->SW, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_release(NW);
			kprintf("LEAVING->S, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			//lock_release(NW);
			lock_release(SW);
			lock_release(NtoS);
			break;
		case 1:
			lock_acquire(EtoW);
			lock_acquire(NE);
			//lock_acquire(NW);
			kprintf("ENTERING->NE, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_acquire(NW);
			kprintf("ENTERING->NW, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_release(NE);
			kprintf("LEAVING->W, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			//lock_release(NE);
			lock_release(NW);
			lock_release(EtoW);
			break;
		case 2:
			lock_acquire(StoN);
			lock_acquire(SE);
			//lock_acquire(NE);
			kprintf("ENTERING->SE, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_acquire(NE);
			kprintf("ENTERING->NE, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_release(SE);
			kprintf("LEAVING->N, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			//lock_release(SE);
			lock_release(NE);
			lock_release(StoN);
			break;
		case 3:
			lock_acquire(WtoE);
			lock_acquire(SW);
			//lock_acquire(SE);
			kprintf("ENTERING->SW, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_acquire(SE);
			kprintf("ENTERING->SE, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_release(SW);
			kprintf("LEAVING->E, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			//lock_release(SW);
			lock_release(SE);
			lock_release(WtoE);
			break;
	}

	lock_release(control);
}


/*
 * turnleft()
 *
 * Arguments:
 *      unsigned long cardirection: the direction from which the car
 *              approaches the intersection.
 *      unsigned long carnumber: the car id number for printing purposes.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      This function should implement making a left turn through the 
 *      intersection from any direction.
 *      Write and comment this function.
 */

static
void
turnleft(unsigned long cardirection,
         unsigned long carnumber,
	 unsigned long turndestination)
{
        /*
         * Avoid unused variable warnings.
         */

        (void) cardirection;
        (void) carnumber;

	// controls the flow of the traffic
	lock_acquire(control);

	/*
	 * Switch Case:
	 * 	case is chosen based on direction the car is coming from.
	 *
	 * Purpose:
	 * 	turn left through the intersection and print statements when
	 * 	in the specific quadrant or leaving. locks on the quadrants and
	 * 	the direction that the car is coming from so another car can't
	 * 	travel left at the same time from the same direction.
	 */
	switch(cardirection)
	{
		case 0:
			lock_acquire(NtoE);
			lock_acquire(NW);
			//lock_acquire(SW);
			//lock_acquire(SE);
			kprintf("ENTERING->NW, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_acquire(SW);
			kprintf("ENTERING->SW, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_release(NW);
			lock_acquire(SE);
			kprintf("ENTERING->SE, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_release(SW);
			kprintf("LEAVING->E, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			//lock_release(NW);
			//lock_release(SW);
			lock_release(SE);
			lock_release(NtoE);
			break;
		case 1:
			lock_acquire(EtoS);
			lock_acquire(NE);
			//lock_acquire(NW);
			//lock_acquire(SW);
			kprintf("ENTERING->NE, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_acquire(NW);
			kprintf("ENTERING->NW, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_release(NE);
			lock_acquire(SW);
			kprintf("ENTERING->SW, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_release(NW);
			kprintf("LEAVING->S, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			//lock_release(NE);
			//lock_release(NW);
			lock_release(SW);
			lock_release(EtoS);
			break;
		case 2:
			lock_acquire(StoW);
			lock_acquire(SE);
			//lock_acquire(NE);
			//lock_acquire(NW);
			kprintf("ENTERING->SE, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_acquire(NE);
			kprintf("ENTERING->NE, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_release(SE);
			lock_acquire(NW);
			kprintf("ENTERING->NW, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_release(NE);
			kprintf("LEAVING->W, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			//lock_release(SE);
			//lock_release(NE);
			lock_release(NW);
			lock_release(StoW);
			break;
		case 3:
			lock_acquire(WtoN);
			lock_acquire(SW);
			//lock_acquire(SE);
			//lock_acquire(NE);
			kprintf("ENTERING->SW, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_acquire(SE);
			kprintf("ENTERING->SE, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_release(SW);
			lock_acquire(NE);
			kprintf("ENTERING->NE, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_release(SE);
			kprintf("LEAVING->N, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			//lock_release(SW);
			//lock_release(SE);
			lock_release(NE);
			lock_release(WtoN);
			break;
	}

	lock_release(control);
}


/*
 * turnright()
 *
 * Arguments:
 *      unsigned long cardirection: the direction from which the car
 *              approaches the intersection.
 *      unsigned long carnumber: the car id number for printing purposes.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      This function should implement making a right turn through the 
 *      intersection from any direction.
 *      Write and comment this function.
 */

static
void
turnright(unsigned long cardirection,
          unsigned long carnumber,
	  unsigned long turndestination)
{
        /*
         * Avoid unused variable warnings.
         */

        (void) cardirection;
        (void) carnumber;

	// controls the flow of the traffic
	lock_acquire(control);

	/*
	 * Switch Case:
	 * 	case is chosen based on direction the car is coming from.
	 *
	 * Purpose:
	 * 	turn right through the intersection and print statements when
	 * 	in the specific quadrant or leaving. locks on the quadrants and
	 * 	the direction that the car is coming from so another car can't
	 * 	travel right at the same time from the same direction.
	 */
	switch(cardirection)
	{
		case 0:
			lock_acquire(NtoW);
			lock_acquire(NW);
			kprintf("ENTERING->NW, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			kprintf("LEAVING->W, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_release(NW);
			lock_release(NtoW);
			break;
		case 1:
			lock_acquire(EtoN);
			lock_acquire(NE);
			kprintf("ENTERING->NE, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			kprintf("LEAVING->N, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_release(NE);
			lock_release(EtoN);
			break;
		case 2:
			lock_acquire(StoE);
			lock_acquire(SE);
			kprintf("ENTERING->SE, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			kprintf("LEAVING->E, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_release(SE);
			lock_release(StoE);
			break;
		case 3:
			lock_acquire(WtoS);
			lock_acquire(SW);
			kprintf("ENTERING->SW, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			kprintf("LEAVING->S, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
			lock_release(SW);
			lock_release(WtoS);
			break;
	}

	lock_release(control);
}


/*
 * approachintersection()
 *
 * Arguments: 
 *      void * unusedpointer: currently unused.
 *      unsigned long carnumber: holds car id number.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      Change this function as necessary to implement your solution. These
 *      threads are created by createcars().  Each one must choose a direction
 *      randomly, approach the intersection, choose a turn randomly, and then
 *      complete that turn.  The code to choose a direction randomly is
 *      provided, the rest is left to you to implement.  Making a turn
 *      or going straight should be done by calling one of the functions
 *      above.
 */
 
static
void
approachintersection(void * unusedpointer,
                     unsigned long carnumber)
{
        int cardirection;
	int turndirection;
	int turndestination;

        /*
         * Avoid unused variable and function warnings.
         */

        (void) unusedpointer;
        (void) carnumber;
	(void) gostraight;
	(void) turnleft;
	(void) turnright;

        /*
         * cardirection is set randomly.
         */

        cardirection = random() % 4;
	turndirection = random() % 3;

	/*
	 * Switch Case:
	 * 	case is chosen based on direction the car is coming from.
	 *
	 * Nested Switch Case:
	 * 	case is then chosen based on the turn direction
	 * 	0 = gostraight, 1 = turnleft, 2 = turnright
	 *
	 * Purpose:
	 * 	choose the function based on the turndirection of the car and
	 * 	specific messages are printed for those directions and where
	 * 	they are coming from.
	 *
	 * Note:
	 * 	could have been made a lot simpler but the beginning we went for
	 * 	specific understanding of the problem.
	 */
	switch(cardirection)
	{
		case 0:
			switch(turndirection)
			{
				case 0:
					turndestination = 2;
					kprintf("APPROACHING->N, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
					gostraight(cardirection, carnumber, turndestination);
					break;
				case 1:
					turndestination = 1;
					kprintf("APPROACHING->N, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
					turnleft(cardirection, carnumber, turndestination);
					break;
				case 2:
					turndestination = 3;
					kprintf("APPROACHING->N, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
					turnright(cardirection, carnumber, turndestination);
					break;
			}
			break;
		case 1:
			switch(turndirection)
			{
				case 0:
					turndestination = 3;
					kprintf("APPROACHING->E, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
					gostraight(cardirection, carnumber, turndestination);
					break;
				case 1:
					turndestination = 2;
					kprintf("APPROACHING->E, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
					turnleft(cardirection, carnumber, turndestination);
					break;
				case 2:
					turndestination = 0;
					kprintf("APPROACHING->E, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
					turnright(cardirection, carnumber, turndestination);
					break;
			}
			break;
		case 2:
			switch(turndirection)
			{
				case 0:
					turndestination = 0;
					kprintf("APPROACHING->S, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
					gostraight(cardirection, carnumber, turndestination);
					break;
				case 1:
					turndestination = 3;
					kprintf("APPROACHING->S, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
					turnleft(cardirection, carnumber, turndestination);
					break;
				case 2:
					turndestination = 1;
					kprintf("APPROACHING->S, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
					turnright(cardirection, carnumber, turndestination);
					break;
			}
			break;
		case 3:
			switch(turndirection)
			{
				case 0:
					turndestination = 1;
					kprintf("APPROACHING->W, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
					gostraight(cardirection, carnumber, turndestination);
					break;
				case 1:
					turndestination = 0;
					kprintf("APPROACHING->W, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
					turnleft(cardirection, carnumber, turndestination);
					break;
				case 2:
					turndestination = 2;
					kprintf("APPROACHING->W, Car: %lu, Direction: %s, Destination: %s\n", carnumber, direction[cardirection], direction[turndestination]);
					turnright(cardirection, carnumber, turndestination);
					break;
			}
			break;
	}

	// decrements the count meaning a car has left
	count--;
}


/*
 * createcars()
 *
 * Arguments:
 *      int nargs: unused.
 *      char ** args: unused.
 *
 * Returns:
 *      0 on success.
 *
 * Notes:
 *      Driver code to start up the approachintersection() threads.  You are
 *      free to modiy this code as necessary for your solution.
 */

int
createcars(int nargs,
           char ** args)
{
	//initialize the menu count and count = to the number of cars
	//for the dreaded busy wait lock...
	menulock = lock_create("menulock");
	count = NCARS;

        int index, error;

        /*
         * Avoid unused variable warnings.
         */

        (void) nargs;
        (void) args;

        /*
         * Start NCARS approachintersection() threads.
         */

	//initialize the locks before the loop
	//so you don't get multiple locks
	stoplight_init();

        for (index = 0; index < NCARS; index++) {

		error = thread_fork("approachintersection thread",
                                    NULL,
                                    index,
                                    approachintersection,
                                    NULL
                                    );

                /*
                 * panic() on error.
                 */

                if (error) {
                        
                        panic("approachintersection: thread_fork failed: %s\n",
                              strerror(error)
                              );
                }
		
        }
	
	//after 74 compilations...we decided to throw in the towel and use a
	//busy wait for the protection of the menu boot.
	lock_acquire(menulock);
	while(count != 0);
	lock_release(menulock);
	lock_destroy(menulock);

	//destroy all the locks before exit
	stoplight_cleanup();

        return 0;
}
