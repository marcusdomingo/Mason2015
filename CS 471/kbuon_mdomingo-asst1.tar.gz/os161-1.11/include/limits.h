/* Get the limits the kernel exports. libc doesn't have any limits :-) */ 
#include <kern/limits.h>
