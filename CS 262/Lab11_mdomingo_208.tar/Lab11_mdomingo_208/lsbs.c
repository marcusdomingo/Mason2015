#include <stdlib.h>
#include <stdio.h>
#include "lsbs.h"

void setlsbs(unsigned char *p, unsigned char b0)
{
        int i;

        for (i = 0; i < 8; i++)
        {
                if ((b0 % 2) == 0)	// if the byte is even then... 
                {
                        p[i] |= 1;	// or character with 000000001 to make lsb 1
                }
                else			// else...
                {
                        p[i] &= 254;	// and character with 11111110 to make the lsb 0
                }

                b0 = b0 >> 1;		// shift the byte over one to the right to analyze next bit
        }
}

unsigned char getlsbs(unsigned char *p)
{
        int i;
        unsigned char lsbs = 0;

        for (i = 0; i < 8; i++)
        {
                lsbs = lsbs >> 1;	// shift the lsbs over one to the right to place the next lsbs in front
                if ((p[i] % 2) == 0)	// if the character is even then...
                {
                        lsbs |= 128;	// or lsbs with 10000000 to change the lsbs to 1
                }
        }

        return lsbs;			// return the value of the lsbs
}
