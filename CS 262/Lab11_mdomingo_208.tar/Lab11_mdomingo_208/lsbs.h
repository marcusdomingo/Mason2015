#include <stdlib.h>
#include <stdio.h>

void setlsbs(unsigned char *p, unsigned char b0);	// set the least significant bit of each character to the corresponding bit number in the byte
unsigned char getlsbs(unsigned char *p);		// get the least significant bit of each character in the array
