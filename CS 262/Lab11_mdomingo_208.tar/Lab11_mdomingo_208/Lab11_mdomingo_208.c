//Marcus Domingo and G00987958
//CS 262, Lab section 208
//Lab 11

#include <stdlib.h>
#include <stdio.h>
#include "lsbs.h"

#define BYTETOBINARYPATTERN "%d%d%d%d%d%d%d%d\n"

#define BYTETOBINARY(byte)  \
        (byte & 0x80 ? 1 : 0), \
        (byte & 0x40 ? 1 : 0), \
        (byte & 0x20 ? 1 : 0), \
        (byte & 0x10 ? 1 : 0), \
        (byte & 0x08 ? 1 : 0), \
        (byte & 0x04 ? 1 : 0), \
        (byte & 0x02 ? 1 : 0), \
        (byte & 0x01 ? 1 : 0)

#define PRINTBIN(x) printf(BYTETOBINARYPATTERN, BYTETOBINARY(x));

int main(int argc, char *argv[])
{
	// initialize variables
	int i;
	int arg1 = atoi(argv[1]);
	srandom(arg1);
	unsigned char p[8];
	unsigned char byte0 = random();
	
	for (i = 0; i < 8; i++)			// assign random numbers
	{
		p[i] = random() % 256;
	}
	
	printf("\nCharacters in decimal:\n");
	for (i = 0; i < 8; i++)			// print out the characters in decimal
	{
		printf("%d\n", p[i]);
	}
	
	printf("\nByte0 value in decimal:\n");
	printf("%d\n", byte0);			// print out the byte in decimal
	
	printf("\nCharacters in binary:\n");
	for (i = 0; i < 8; i++)			// print out the characters in binary
	{
		PRINTBIN(p[i]);
	}
	
	printf("\nByte0 value in binary:\n");
	PRINTBIN(byte0);			// print out the byte in binary
	
	setlsbs(p, byte0);			// call to setlsbs()
	
	printf("\nThe modified characters in decimal:\n");
        for (i = 0; i < 8; i++)			// print out the modified characters in decimal
        {
                printf("%d\n", p[i]);
        }

        printf("\nThe modified characters in binary:\n");
        for (i = 0; i < 8; i++)			// print out the modified characters in binary
        {
                PRINTBIN(p[i]);
        }
	
	printf("\nThe getlsbs() character in decimal:\n");
	printf("%d\n", getlsbs(p));		// print out the getlsbs character in decimal
	printf("\nThe getlsbs() character in binary:\n");
	PRINTBIN(getlsbs(p));			// print out the getlsbs character in binary
	
	printf("\n***Original Byte***\n");
	PRINTBIN(byte0);			// reprint the original byte in binary
	
}
