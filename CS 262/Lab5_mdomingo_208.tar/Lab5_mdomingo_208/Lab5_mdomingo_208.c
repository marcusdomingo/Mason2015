// Marcus Domingo and G00987958
// CS 262, Lab Section 208
// Lab 5

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

int main(int argc, char *argv[])
{
	/*Declaring files for input as well as a variable for the input*/
	FILE *inFile = NULL;
	FILE *outFile = NULL;
	char line[300];
	
	/*Checks to make sure that only 3 arguments were input*/
	if (argc > 3)
	{
		printf("You entered more than 3 arguments. The executible counts as 1 argument\n");
		exit(1);
	}

	/*Takes the 2nd argument as the input file*/
	inFile = fopen(argv[1], "r");
	
	/*Assert to check and make sure that the input file is existing*/
	assert(inFile != NULL);
	
	/*Other way to check to see if the input file exists*/
	//if (inFile == NULL)
	//{
	//	printf("Error opening file\n");
	//	exit(1);
	//}

	/*Takes the 3rd argument as the input file*/
	outFile = fopen(argv[2], "w");

	/*Checks to make sure that the output file is existing*/
	if (outFile == NULL)
	{
		printf("Error opening file\n");
		exit(1);
	}
	
	/*Scans the input file until the end and prints to the output file*/
	while (fgets(line, 300, inFile) != NULL)
	{
		/*echoes what it is writing to the output file without declaration of NDEBUG*/
		#ifndef NDEBUG
			printf("%s", line);
		#endif

		fprintf(outFile, "%s", line);
	}

	/*close files*/
	fclose(inFile);
	fclose(outFile);
	
	exit(0);
}
