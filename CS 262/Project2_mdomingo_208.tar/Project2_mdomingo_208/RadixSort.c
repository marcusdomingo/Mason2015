//Marcus Domingo and G00987958
//CS 262, Lab section 208
//Project 2

#include <stdlib.h>
#include <stdio.h>
#include "link.h"

int main(int argc, char *argv[])
{
	if (argc != 5)	//check for 5 arguments in command line
	{
		printf("You didn't put in 5 arguments...The executible counts as an argument. Try again.\n");
		exit(0);
	}
	
	//initialization of variables
	int i, ranNum;
	int arg1 = atoi(argv[1]);
	int arg2 = atoi(argv[2]);
	int arg3 = atoi(argv[3]);
	int arg4 = atoi(argv[4]);
	srandom(arg1);
	
	if (arg2 < 0)	//check that the number of random numbers to use is not negative
	{
		printf("You entered a negative value for your quantity of random numbers. Try again.\n");
		exit(0);
	}
	
	if ((arg3 < 0) || (arg4 < 0))	//check that a negative number wasn't inserted for low to high
	{
		printf("Your random number range has a negative number. Please input positive numbers only. Try again\n");
		exit(0);
	}
	
	ListNode *previous, *head;
	head = newList();	//make a new Linked List
	previous = head;	//set previous to the head
	
	for (i = 0; i < arg2; i++)
	{
		ranNum = (random() % ((arg4 - arg3) + 1)) + arg3;	//generate the random number with the given range
		previous = insert(previous, ranNum);	//insert the random number into the linked list
	}
	
	printf("\nThe unsorted linked list is: ");
	printList(head);	//print the unsorted list
	
	head = radixSort(head, findDigits(head)); //radix sort the linked list
	
	printf("\nThe sorted linked list is: ");
	printList(head);	//print the sorted list
	deleteList(head);	//delete the entire list and free all memory
}

ListNode *radixSort(ListNode *head, int digits)
{
	//initialization of variables
	int i, j, x;
	int place = 1, s = 0;
	ListNode *current, *temp;
	current = head->next;
	ListNode *heads[10], *tails[10];
	
	printf("********************************************");

	printf("\nS%d = ", s);  //print the stitched bucket list
	printBucket(current);   //used the printBucket because the function prints from beginning of linked list with no dummy head
	s++;

	printf("\n********************************************\n");
	
	for (i = 0; i < digits; i++)
	{
		for (j = 0; j < 10; j++)	//NULL every node in the node array
		{
			heads[j] = NULL;
			tails[j] = NULL;
		}
		
		while (current != NULL)
		{
			x = (current->data / place) % 10;	//find the bucket number for each corresponding data
			temp = current;			//set temp to the current node
			current = current->next;	//go to the next node
			temp->next = NULL;		//point the temp node to NULL so it doesn't point to anything
			
			if (heads[x] == NULL)	//if head is null for bucket x then set the head and tail of that bucket to temp node
			{
				heads[x] = temp;
				tails[x] = temp;
			}
			else			//else set the next node to temp and then set that to the tail
			{
				tails[x]->next = temp;
				tails[x] = temp;
			}
		}
		
		printf("\nRunning Sort: %d's place.", place);
			
		for (j = 0; j < 10; j++)	//print out all 10 buckets
		{
			printf("\nBucket %d: ", j);
			printBucket(heads[j]);
		}
		
		x = findNum(heads);	//find where the first number is in the buckets
	
		current = heads[x];	//set the current to the head of the bucket with the first number in it 
		temp = tails[x];	//set temp to the tail of that bucket
		x++;			//increment x
			
		while (x < 10)		//while x is less than 10 plug in all the buckets in order into the linked list
		{
			if (heads[x] != NULL)
			{
				temp->next = heads[x];
				temp = tails[x];
			}

			x++;
		}
		
		printf("\n********************************************");		
		
		printf("\nS%d = ", s);	//print the stitched bucket list
		printBucket(current);	//used the printBucket because the function prints from beginning of linked list with no dummy head
		s++;
		
		printf("\n********************************************\n");
		
		place = place * 10; //place holder * 10
	}
	
	head->next = current;	//point the dummy head to the new linked list
	return head;
}
