#include <stdio.h>
#include <stdlib.h>

typedef struct Node					//struct of the linked list node
{
  int data;
  struct Node *next;
}ListNode;

ListNode *insert(ListNode *tail, int data);             // insert and element at tail
ListNode *delete(ListNode *prev);                       // deletes the node after previous
ListNode *newList(void);                                // make a new list with a dummy head
void deleteList(ListNode *head);			// delete the entire list
void printList(ListNode *head);                         // print the list
void printBucket(ListNode *head);			// print the buckets
int findNum(ListNode *heads[]);				// find the number to start putting back into the original linked list
int findDigits(ListNode *head);				// find how many place holders we need to test (ie. 1's 10's 100's = 3)
ListNode *radixSort(ListNode *head, int digits);	// radix sort the linked list
