#include <stdlib.h>
#include <stdio.h>
#include "link.h"

ListNode *newList()		//Make the dummy head of the Linked List
{
        ListNode *head = (ListNode *) malloc(sizeof(ListNode));
	if (head == NULL)
	{
		printf("Memory was not allocated for the head node.\n");
		exit(0);
	}
	
        head->next = NULL;

        return head;
}

ListNode *delete(ListNode *prev)		//Not used in program*** deletes the node after the previous node
{
	if (prev == NULL)
	{
		printf("Node can't be NULL");
	}
	
	ListNode *deleteNode;
	deleteNode = prev->next;
	free(deleteNode);
	
	return prev;
}

ListNode *insert(ListNode *prev, int data)		//Inserts a node after the previous node
{
	if (prev == NULL)
	{
		printf("Node can't be NULL");
	}
	
	ListNode *newNode = (ListNode *) malloc(sizeof(ListNode));
	if (newNode == NULL)
	{
		printf("Memory was not allocated for the new node.\n");
		exit(0);
	}

	newNode->data = data;
	newNode->next = prev->next;
	prev->next = newNode;
	prev = newNode;
	
	return prev;
}

int length(ListNode *head)			//Not used in program*** Gets the length of the linked list
{
	int len = 0;
	ListNode *current;
	current = head->next;
	
	while (current != NULL)
	{
		current = current->next;
		len++;
	}
	
	return len;
}

void printList(ListNode *head)			//Prints out the Linked List
{
        ListNode *current;
        current = head->next;

        while (current != NULL)
        {
                printf("%d  ", current->data);
                current = current->next;
        }
	
	printf("\n");
}

void printBucket(ListNode *head)		//Prints out the Buckets
{
	while (head != NULL)
	{
		printf("%d  ", head->data);
		head = head->next;
	}
}

void deleteList(ListNode *head)			//Deletes the entire linked list
{
	ListNode *current;
	current = head;
	ListNode *next;
	
	while (current != NULL)
	{
		next = current->next;
		free(current);
		current = next;
	}
}

int findNum(ListNode *heads[])			//Find the starting Bucket to reassign back into the Linked List
{
	int x = 0;
	
	while (heads[x] == NULL)
	{
		x++;
	}
	
	return x;
}

int findDigits(ListNode *head)			//Find the number of place holders we need to test for
{
        int maxValue = -1;
        ListNode *current;
        current = head->next;
	int digits = 0;

        while (current != NULL)
        {
                if (current->data > maxValue)
                {
                        maxValue = current->data;
                }

                current = current->next;
        }
	
	while (maxValue > 0)
	{
		digits = digits + 1;
		maxValue = maxValue / 10;
	}
	
	return digits;
}
