//Marcus Domingo and G00987958
//CS 262, Lab 208
//Project 3

#include <stdlib.h>
#include <stdio.h>
#include "image.h"

// prototype functions
unsigned char getlsbs8(unsigned char *p); // get 8 bit lsbs
unsigned char getlsbs4(unsigned char *p); // get 4 bit lsbs

int main(int argc, char *argv[])
{
	// intialize variables
	int i, k = 0, buffSize1, buffSize2 = 0;
	struct Buffer b = {NULL, 0, 0};
	struct Image img = {0, NULL, NULL, NULL, NULL, 0, 0};
	byte b0, gNumber[8];

	// allocate memory and check memory was allocated
	b.data = (byte *)malloc(sizeof(byte)*MIN_BUFFER_SIZE);
	if(b.data == NULL)
	{
		printf("\nMemory failed to allocate.\n");
		exit(1);
	}

	// must enter 3 arguments
	if (argc != 3)
	{
		printf("\n%s <stego_file> <file_to_write> \n", argv[0]);
		exit(1);
	}
	
	// read in stego image
	ReadImage(argv[1], &img);
	
	// read in and store the buffer size
	for(i = 0; i < 4; i++)
	{
		buffSize1 = getlsbs8(&GetGray(k));
		buffSize1 = buffSize1 << (8*i);  // shift the read in to the right 8*i times
		buffSize2 = buffSize2 | buffSize1;  // or with other 8
		
		k += 8;
	//printf("%d\n", buffSize2);
	}
	b.size = buffSize2;

	// read in and store the G# of the student
	for(i = 0; i < 8; i++)
	{
		gNumber[i] = getlsbs4(&GetGray(k));
		gNumber[i] = gNumber[i] >> 4;
		k += 4;
	}
	
	// print the G#
	printf("\nG#: ");
	for(i = 0; i < 8; i++)
	{
		printf("%d", gNumber[i]);
	}
	printf("\n");
	
	// read in and store the message from the image
	for(i = 0; i < b.size; i++)
	{
		SetByte(i, getlsbs8(&GetGray(k)));
		k += 8;
	}

	WriteBinaryFile(argv[2], b); // write the message to the output file
	free(b.data); // free memory for buffer data
	free(img.gray); // free memory for image gray
}

unsigned char getlsbs8(unsigned char *p)
{
        int i;
        unsigned char lsbs = 0;

        for (i = 0; i < 8; i++)
        {
                lsbs = lsbs >> 1; // shift the lsbs over one to the right to place the next lsbs in front
                if ((p[i] % 2) == 0)  // if the character is even then...
                {
                        lsbs |= 128;  // or lsbs with 10000000 to change the lsbs to 1
                }
        }

        return lsbs;   // return the value of the lsbs
}

unsigned char getlsbs4(unsigned char *p)
{
        int i;
        unsigned char lsbs = 0;

        for (i = 0; i < 4; i++)
        {
                lsbs = lsbs >> 1; // shift the lsbs over one to the right to place the next lsbs in front
                if ((p[i] % 2) == 0)  // if the character is even then...
                {
                        lsbs |= 128;  // or lsbs with 10000000 to change the lsbs to 1
                }
        }

        return lsbs;   // return the value of the lsbs
}
