/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*
 * Stego.c: A program for manipulating images                           *
 *++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

//EDITED BY: Marcus Domingo and G00987958

#include <string.h>
#include "image.h"

// prototype functions
void setlsbs8(unsigned char *p, unsigned char b0); // set the lsbs for 8 bits
void setlsbs4(unsigned char *p, unsigned char b0); // set the lsbs for 4 bits

int main(int argc, char *argv[])
{
  // initialize variables	 
  int i, k = 0, cover_bits, bits, gNumber[8] = {0, 0, 9, 8, 7, 9, 5, 8};
  struct Buffer b = {NULL, 0, 0};
  struct Image img = {0, NULL, NULL, NULL, NULL, 0, 0};
  byte b0;
   
  if (argc != 4) 
    {
      printf("\n%s <cover_file> <stego_file> <file_to_hide> \n", argv[0]);
      exit(1);
    }
  ReadImage(argv[1],&img);       // read image file into the image buffer img
                                 // the image is an array of unsigned chars (bytes) of NofR rows
                                 // NofC columns, it should be accessed using provided macros
  ReadBinaryFile(argv[3],&b);    // Read binary data
 

  // hidden information 
  // first four bytes is the size of the hidden file
  // next 4 bytes is the G number (4 bits per digit)
  if (!GetColor)
    cover_bits = img.NofC*img.NofR;
  else 
    cover_bits = 3*img.NofC*img.NofR;    
  bits = (8 + b.size)*8;
  if (bits > cover_bits)
    {
      printf("Cover file is not large enough %d (bits) > %d (cover_bits)\n",bits,cover_bits);
      exit(1);
    }

  // embed four size bytes for the Buffer's size field
  // 
  //

  //printf("%d", b.size);
  
  // set the lsbs of 0 to 31 characters with b.size
  for(i = 0; i < 4; i++)
  {
    b0 = (b.size >> 8*i);
    //printf("\n%d\n", b0);
    setlsbs8(&GetGray(k), b0);
    k += 8;
  }

  // embed the eight digits of your G# using 4 bits per digit
  // 
  //
  //
  
  // set the lsbs of 32 to 63 with 4 bits of each digit in G#
  for(i = 0; i < 8; i++)
  {
    setlsbs4(&GetGray(k), gNumber[i]);
    k += 4;
  }

  // set the lsbs of 64 and up of the payload
  for (i=0; i<b.size; i++)
    {
      // here you embed information into the image one byte at the time
      // note that you should change only the least significant bits of the image
      b0 = GetByte(i);
      setlsbs8(&GetGray(k), b0);
      k += 8;
    }

  WriteImage(argv[2],img);  // output stego file (cover_file + file_to_hide)
  free(b.data); // free the buffer data
  free(img.gray); // free the image gray
}

void setlsbs8(unsigned char *p, unsigned char b0)
{
        int i;

        for (i = 0; i < 8; i++)
        {
                if ((b0 % 2) == 0)      // if the byte is even then... 
                {
                        p[i] |= 1;      // or character with 000000001 to make lsb 1
                }
                else                    // else...
                {
                        p[i] &= 254;    // and character with 11111110 to make the lsb 0
                }

                b0 = b0 >> 1;           // shift the byte over one to the right to analyze next bit
        }
}

void setlsbs4(unsigned char *p, unsigned char b0)
{
        int i;

        for (i = 0; i < 4; i++)
        {
                if ((b0 % 2) == 0)      // if the byte is even then... 
                {
                        p[i] |= 1;      // or character with 000000001 to make lsb 1
                }
                else                    // else...
                {
                        p[i] &= 254;    // and character with 11111110 to make the lsb 0
                }

                b0 = b0 >> 1;           // shift the byte over one to the right to analyze next bit
        }
}
