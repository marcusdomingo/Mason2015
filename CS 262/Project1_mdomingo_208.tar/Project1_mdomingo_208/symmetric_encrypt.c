// Marcus Domingo and G00987958
// CS 262, Lab Section 208
// Project 1

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	/* Initialize files, variables, and seed srandom()*/
	FILE *inFile = NULL;
	FILE *outFile = NULL;
	int key = atoi(argv[1]);
	srandom(key);
	char p, c, p1, c1, r;
	
	/*check to make sure more than 4 arguments weren't used*/
	if (argc > 4)
	{
		printf("You entered more than 4 arguments. The executible counts as 1 argument\n");
		exit(1);
	}
	
	/*check to make sure less than 4 arguments weren't used*/
	if (argc < 4)
	{
		printf("This program requires 4 arguments to run properly:\nexecutible, key, input file, and output file.\n");
		exit(1);
	}
	
	/*Open input file*/
	inFile = fopen(argv[2], "r");
	
	/*check to make sure that the file opened correctly*/
	if (inFile == NULL)
	{
		printf("Error opening file\n");
		exit(1);
	}
	
	/*Open output file*/
	outFile = fopen(argv[3], "w");
	
	/*check to make sure that the file opened correctly*/
	if (outFile == NULL)
	{
		printf("Error opening file\n");
		exit(1);
	}
	
	/*read in character by character of input file until the end of the file*/
	while ((p = fgetc(inFile)) != EOF)
	{
		/*random number generator from 0...96*/
		r = random() % 97;

		// change all displayable characters to range [0. . . 96]
		if (p == '\t')
			p1 = 0;
		else if (p == '\n')
			p1 = 1;
		else
			p1 = p - 30;

		c1 = p1 ^ r; // bitwise xor
		
		// turn all output values into displayable characters
		if (c1 == 0)
			c = '\t';
		else if (c1 == 1)
			c = '\n';
		else
			c = c1 + 30;
		
		fprintf(outFile, "%c", c);
	}
	
	/*close files that were opened*/
	fclose(inFile);
	fclose(outFile);
	
	/*exit program*/
	exit(0);
}
