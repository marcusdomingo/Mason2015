#ifndef LAB12_H
#define LAB12_H

#define ARRAY_SIZE (100)

#ifndef NDEBUG
#define PARTIAL_SIZE (10)
#endif

#define PR(x)	#x

#endif
