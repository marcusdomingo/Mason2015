#ifndef FUNCTION1_H
#define FUNCTION1_H

#endif

void Function1();
