//Marcus Domingo and G00987958
//Lab Section 208
//Lab 8

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

//Struct of location with typedef to Location
typedef struct _location
{
	char locationName[35];
	char description[85];
	float Latitude, Longitude;
}Location;

//initializing functions
void ResizeArray(int numLoc, Location **ptr, int numLocTemp);
void AddLocation(Location *ptr, int locInArray);
void PrintArray(Location *ptr, int numberAdded);

int main()
{
	//initializing variables
	char in[32];
	char x;
	Location *ptr;
	int cont = 1;
	int numAdded = 0;
	int locInArr = 0;
	int numLocations;
	int numLocationsTemp;
	
	//get input of the number of locations to be initially used
	printf("Please enter the number of locations: ");
	fgets(in, 32, stdin);
	sscanf(in, "%d\n", &numLocations);
	
	//make a pointer to dynamic memory with the size of the give number of locations
	ptr = (Location *) malloc(sizeof(Location)*numLocations);
	if (ptr == NULL) //check to see if the pointer is null
	{
		fprintf(stderr, "Error allocating memory.\n");
		exit(0);
	}
	
	//continue the menu
	while(cont == 1)
	{
		//menu and get input of option chosen
		printf("\n*****Menu*****\n");
		printf("A. Add an additional location.\n");
		printf("P. Print the current list of locations.\n");
		printf("Q. Quit.\n");
		printf("Enter the desired option A, P, or Q respectively: ");
		fgets(in, 32, stdin);
		sscanf(in, "%c\n", &x);
		printf("\n\n");
	
		//switch for the option
		switch(x)
		{
			case 'A' :
			case 'a' :
				numAdded++; //increase the number of locations you have added
				if(numAdded > numLocations) //check to see if the number you have added is bigger than the number allocated for in memory
				{
					//assign number of desired to a temp and then double the original
					numLocationsTemp = numLocations;
					numLocations = numLocationsTemp * 2;

					//call to resize the array
					ResizeArray(numLocations, &ptr, numLocationsTemp);
				}
				AddLocation(ptr, locInArr); //add the location to the dynamic memory
				locInArr++; //increase the location in the memory that we are adding to
			break;
			case 'P' :
			case 'p' :
				PrintArray(ptr, numAdded); //call to print the array
			break;
			case 'Q' :
			case 'q' :
				printf("The system is quitting...\n");
				free(ptr); //free the memory
				exit(0); //exit the program
			break;
			default : //if a wrong character is entered then...
				printf("\nThe character you entered is not valid, please try again.\n");
		}
	}
	
	return 0;
}

void ResizeArray(int numLocNew, Location **ptr, int numLocOld)
{
	//establish a temporary pointer
	Location *ptrTemp = (Location *) malloc(sizeof(Location)*(numLocNew));
	if (ptrTemp == NULL) //check to see if the pointer is null
	{
		fprintf(stderr, "Error allocating memory.\n");
		exit(0);
	}
	
	//copy from original poiniter to new pointer
	memcpy(ptrTemp, *ptr, sizeof(Location)*numLocOld);
	free(*ptr); //free the original pointer
	*ptr = ptrTemp; //assign new pointer to the original pointer
}

void AddLocation(Location *ptr, int locInArray)
{
	//in value and floats
	char in[85];
	float lati, longi;
	
	//store location in locationName
	printf("Please enter the Location Name: ");
	fgets(ptr[locInArray].locationName, 35, stdin);
	printf("\n");
	
	//store description in Description
	printf("Please enter the Description: ");
	fgets(ptr[locInArray].description, 85, stdin);
        printf("\n");
	
	//take input of Latitude
	printf("Please enter the Latitude: ");
	fgets(in, 85, stdin);
	sscanf(in, "%f\n", &lati);
        printf("\n");
	
	//take input of Longitude
	printf("Please enter the Longitude: ");
	fgets(in, 85, stdin);
        sscanf(in, "%f\n", &longi);
        printf("\n");

	//store the latitude and longitude in the Array
	ptr[locInArray].Latitude = lati;
	ptr[locInArray].Longitude = longi;
}

void PrintArray(Location *ptr, int numberAdded)
{
	//integer for loop
	int i;
	
	//prints out the name, description, latitude, and longitude of the location
	for (i = 0; i < numberAdded; i++)
	{
		printf("Location: %s", ptr[i].locationName);
		printf("Description: %s", ptr[i].description);
		printf("Latitude: %f\n", ptr[i].Latitude);
		printf("Longitude: %f\n\n", ptr[i].Longitude);
	}
}
