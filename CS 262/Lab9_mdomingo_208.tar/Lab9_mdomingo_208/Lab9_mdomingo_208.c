//Marcus Domingo and G00987958
//CS 262, Lab Section 208
//Lab 9

#include <stdlib.h>
#include <stdio.h>

//struct of LList Node with typedef to Node
typedef struct _node
{
	int data; //data in the node
	struct _node *next; //pointer for where the node points to
}Node;

//initialization of functions
void insertNodeSorted(Node **_head, Node *_node);
void printList(Node *_head);
void deleteList(Node **_head);

int main(int argc, char *argv[])
{
	//initialization of variables and seed srandom
	int i = 0;
	int ranNum;
	int arg1 = atoi(argv[1]);
	int arg2 = atoi(argv[2]);
	int arg3 = atoi(argv[3]);
	srandom(arg1);
	
	//check if the correct number of arguments was entered
	if (argc != 4)
	{
		printf("You entered the wrong amount of arguments.\nThe executible counts as one argument\n");
		exit(0);
	}
	
	//allocate memory for the dummy head node
	Node *head = (Node *)malloc(sizeof(Node));
	
	//check to see if memory was allocated for dummy head node
	if (head == NULL)
	{
		printf("Memory was not allocated.\n");
		exit(0);
	}
	
	//reassure that head is pointing to NULL
	head->next = NULL;
	
	//print statement for better output design
	printf("The random numbers being input are:\n");
	
	//for loop to create as many nodes as specified in the command line
	for(i = 0; i < arg2; i++)
	{
		//allocate memory for the node to be added
		Node *node = (Node *)malloc(sizeof(Node));
		
		//check to see if memory was allocated for the node
        	if (node == NULL)
        	{
                	printf("Memory was not allocated.\n");
                	exit(0);
        	}
		
		ranNum = random() % arg3; //calculate the random number for the specified value
		printf("%d\n",ranNum); //print the random number generated
		node->data = ranNum; //insert the number into the node
		node->next = NULL; //set the pointer of the node to NULL
		insertNodeSorted(&head, node); //call to insert node in sorted order function
	}
	
	printList(head); //call to print the linked list
	deleteList(&head); //call to delete the linked list
	
	return (0);
}

void insertNodeSorted(Node **_head, Node *_node)
{
	//initialize a temporary node
	Node *tmp;
	
	//check if the dummy node points to NULL or if the data it points to is greater than the node to be inserted data
	if ((*_head)->next == NULL || (*_head)->next->data >= _node->data)
	{
		_node->next = (*_head)->next; //node points to what the dummy head does
		(*_head)->next = _node; //the head points to the node
	}
	else
	{
		tmp = (*_head)->next; //temporary node is set to the node that head points to
		
		//traverse the list looking for the next NULL pointer or where the node data becomes smaller than the next node
		while (tmp->next != NULL && tmp->next->data < _node->data)
		{
			tmp = tmp->next; //temporary node is set to the next node
		}
		
		_node->next = tmp->next; //node points to what the temporary node does
		tmp->next = _node; //temporary node points to the node
	}
}

void printList(Node *_head)
{
	//set temporary pointer to what the dummy head points to
	Node *tmp =_head->next;
	
	//print statement for better output design
	printf("The input numbers in ascending order are:\n");
	
	//traverse the list printing out each value until you get to the end of the list
	while (tmp != NULL)
	{
		printf("%d\n", tmp->data); //print the data at the current node
		tmp = tmp->next; //temporary node points to the next node
	}
}

void deleteList(Node **_head)
{
	//set temporary pointer to the pointer of the head
	Node *tmp = *_head;
	Node *next; //make node next
	
	//traverse the list freeing each node
	while (tmp != NULL)
	{
		next = tmp->next; //next set to what the temporary node points to
		free(tmp); //free the temporary node
		tmp = next; //temporary node set to next
	}
	
	*_head = NULL; //set the dummy head to NULL
}
