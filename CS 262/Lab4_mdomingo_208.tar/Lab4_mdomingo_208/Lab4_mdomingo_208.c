// Marcus Domingo and G00987958
// CS 262, Lab Section 208
// Lab4

#include <stdlib.h>
#include <stdio.h>

/*Macros to be used*/
#define RNG_SEED (7958)
#define ARRAY_SIZE (20)
#define LOOP_MAX (10)

/*function declarations*/
void InitializeArray(int *numArray, const int arrayLength);
void PrintArray(int *numArray, const int arrayLength);
void ShuffleArray(int *numArray, const int arrayLength);

int main()
{
	/*Local variable declarations and seeding srandom*/
	int numArray[ARRAY_SIZE];
	srandom(RNG_SEED);
	int i;
	
	printf("Name: Marcus Domingo\nLab: 208\n");
	printf("Information:\n   This program will print an array of numbers from 1 to a value N then it will take that array, suffle the values, then print out the shuffle array.");
	printf(" Then the program will reinitialize the array from 1 to a value N and repeat until there have been 10 lines of the shuffled arrays.\n\n");

	/*loop to execute random numbers 10 times*/
	for(i = 0; i < LOOP_MAX; i++)
	{
		InitializeArray(numArray, ARRAY_SIZE);
		PrintArray(numArray, ARRAY_SIZE);
		ShuffleArray(numArray, ARRAY_SIZE);
		PrintArray(numArray, ARRAY_SIZE);
		printf("\n");     /*Extra line for neatness in output*/
	}

	return 0;
}

/*functions that defines the values 1...arrayLength to numArray[0]...numArray[arrayLength]*/
void InitializeArray(int *numArray, const int arrayLength)
{
	int i;

	for(i = 0; i < arrayLength; i++)
	{
		numArray[i] = (i + 1);
	}
}

/*function that prints out the array*/
void PrintArray(int *numArray, const int arrayLength)
{
	int i;

	for(i = 0; i < arrayLength; i++)
	{
		printf("%d ", numArray[i]);
	}
	
	printf("\n");
}

/*function that uses the Fisher-Yates shuffle algorithm*/
void ShuffleArray(int *numArray, const int arrayLength)
{
	int i;
	int value;
	
	/*loop using the random number to swap between the current position value in the array with the random number position value*/
	for(i = arrayLength - 1; i > 0; i--)
	{
		int randomNum = random()%(i + 1);
		
		value = numArray[i];
		numArray[i] = numArray[randomNum];
		numArray[randomNum] = value;
	}
}
