// Marcus Domingo and G00987958
// CS 262 Lab Section 208
// Lab3

#include <stdio.h>
#include <stdlib.h>

char changeChar(char symb);
int changeNum(int num);
void leftTriangle(char symb1, int num1);
void rightTriangle(char symb1, int num1);

int main()
{
	int forever = 1;
	char entry[64];
	char choice;
	char character = ' ';
	int numLines = 0;

	while ((forever) != -1)
	{
		printf("\n******Menu******\n");
		printf("To Enter or Change Character please enter 'C' or 'c'\n");
		printf("To Enter or Change Number please enter 'N' or 'n'\n");
		printf("To Print Triangle Type 1 please enter '1'\n");
		printf("To Print Triangle Type 2 please enter '2'\n");
		printf("To Quit please enter 'Q' or 'q'");
		printf("\n\nEnter your choice now: ");
		fgets(entry, 64, stdin);
		sscanf(entry, "%c\n", &choice);
		printf("\n");

		switch(choice)
		{
			case 'C' :
				character = changeChar(character);
			break;
			case 'c' :
				character = changeChar(character);
			break;
			case 'N' :
				numLines = changeNum(numLines);
			break;
			case 'n' :
				numLines = changeNum(numLines);
			break;
			case '1' :
				leftTriangle(character, numLines);
			break;
			case '2' :
				rightTriangle(character, numLines);
			break;
			case 'Q' :
				printf("Program is now quitting...\n");
				exit(EXIT_SUCCESS);
			break;
			case 'q' :
				printf("Program is now quitting...\n");
				exit(EXIT_SUCCESS);
			break;
			default :
				printf("Incorrect entry please try again...\n");
			break;
		}
	}

	return(0);
}

char changeChar(char x)
{
	char ch1[64];
	char temp;

	printf("Please enter a single character: ");
	printf("\n");
	fgets(ch1, 64, stdin);
	sscanf(ch1, "%c\n", &temp);

	return temp;
}

int changeNum(int y)
{
	int cont;
	char in1[64];
	int temp;

	do
	{
		cont = 0;
		printf("Please enter a number from 1 to 15: ");
		printf("\n");
		fgets(in1, 64, stdin);
		sscanf(in1, "%d\n", &temp);

		if (temp > 15 || temp < 1)
		{
			printf("You entered a number that is not from 1 to 15.\n");
			cont = 1;
		}
		else
			cont = -1;
	}
	while ((cont) != -1);

	return temp;
}

void leftTriangle(char x, int y)
{
	int i;
	int cont = 0;

	for (i = 1; i <= y; i++)
	{
		while(cont != i)
		{
			printf("%c", x);
			cont++;
		}

		printf("\n");
		cont = 0;
	}
}

void rightTriangle(char x, int y)
{
	int i;
	int cont1 = y;
	int cont2 = 0;

	for(i = 1; i <= y; i++)
	{
		while(cont1 != i)
		{
			printf(" ");
			cont1--;
		}
		
		while(cont2 != i)
		{
			printf("%c", x);
			cont2++;
		}
		
		printf("\n");
		cont1 = y;
		cont2 = 0;
	}
}
