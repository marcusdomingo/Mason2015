#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "log.h"

//arrays for TLB and PT
int TLB[8];
int PT[128];

void searchPT(int va)
{
	//calculations from virtual address
	int entry = va >> 10;
	int VPO = va & 0x3FF;

	//unpacking flag and ppn
	int ppn = PT[entry] >> 1;
	int flag = PT[entry] & 0x1;

	//getting physical address
	int pa = (ppn << 10) | VPO;

	//check validity flag
	if(flag != 0)
	{
		//in physical memory
		printf("Physical Address: 0x%x from the page table\n", pa);
		log_it(FROM_PT, va, pa);
	}
	else
	{
		//not in physical memory
		printf("Page fault\n");
		log_it(PAGE_FAULT, va, pa);
	}

	//get the index and tag for TLB
	int TLBT = va >> 13;
	int TLBI = (va >> 10) & 0x7;

	//pack the number
	int packednum = (((ppn << 3) | TLBT) << 1) | flag;

	//put packed number at index
	TLB[TLBI] = packednum;
}

int searchTLB(int va)
{
	//calculations from virtual address
	int TLBT = va >> 13;
	int TLBI = (va >> 10) & 0x7;
	int VPO = va & 0x3FF;

	//unpacking tag, ppn, and flag
	int tag = (TLB[TLBI] >> 1 ) & 0x7;
	int ppn = TLB[TLBI] >> 4;
	int flag = TLB[TLBI] & 0x1;

	//getting physical address
	int pa = (ppn << 10) | VPO;

	//check tags
	if(TLBT == tag)
	{
		//check validty flag
		if(flag != 0)
		{
			//in physical memory
			printf("Physical Address: 0x%x from the tlb\n", pa);
			log_it(FROM_TLB, va, pa);
		}
		else
		{
			//not in physical memory
			printf("Page fault\n");
			log_it(PAGE_FAULT, va, pa);
		}
		return 0;
	}
	else
		return 1;
}

int main(int argc, char *argv[])
{
	start_logging();

	//open .pt file
	strcat(argv[1], ".pt");
	FILE *pageTable = fopen(argv[1], "r");

	//initialize
	int i = 0;
	int flag;
	int ppn;

	//scan file and pack number for PT
	while(fscanf(pageTable, "%d %d", &flag, &ppn)>0)
	{
		int packednum = (ppn << 1) | flag;
		PT[i] = packednum;
		i++;
	}

	//close file
	fclose(pageTable);

	//load -1 in TLB
	for(i = 0; i < 8; i++)
	{
		TLB[i] = -1;
	}

	int va = 0;

	//loop forever
	while(1)
	{
		//enter address
		printf("Enter a virtual address or -1 to exit: ");
		scanf("%d", &va);
		
		//if -1 exit
		if(va == -1)
			break;

		//virtual address in hex
		printf("Virtual Address: 0x%x\n", va);

		//check for 17 bit virtual address
		if(va <= 0x1FFFF)
		{
			//search TLB then PT
			if(searchTLB(va) == 1)
				searchPT(va);
		}
		else
		{
			//virtual address too big
			printf("Illegal virtual address\n");
			log_it(ILLEGAL, va, 0);
		}
	}

	stop_logging();
	exit(0);
}
