//Author: Marcus Domingo G#: G00987958
//Last Modified: 11/29/16

#include <stdio.h>
#include <stdlib.h>

#include "memory.h"

extern mem_ptr Heap;


mem_ptr
mm_malloc(int size) {
  /* Input: size of the block needed
     Output: 
       Return a pointer to a mem_rec of the appropriate size (new_size).
       This block should be found using first-fit.     
       If there is nowhere to place a block of the given size, call error_msg(1) 
          and return a NULL pointer
  */

  int new_size = ALIGN(size);

  mem_ptr p = Heap;
  mem_ptr new_rec = NULL;

  //search for the first free block that will fit the size
  while(p != NULL)
  {
  	if(p->size >= new_size)
	{
		break;
	}
  	p = p->next;
  }

  //if p is null or the size is smaller then there is no fit so call error_msg(1)
  if(p == NULL || p->size < new_size)
  {
  	error_msg(1);
	return NULL;
  }

  //memory allocate and set size and address for mem_rec
  new_rec = (mem_ptr)malloc(sizeof(mem_rec));
  new_rec->size = new_size;
  new_rec->address = p->address;

  //adjust free block
  p->address = p->address + new_size;
  p->size = p->size - new_size;

  //if the adjusted free block size is 0 remove it
  if(p->size == 0)
  {
  	if(p != Heap)
	{
		if(p->next != NULL)
			p->next->previous = p->previous;

		p->previous->next = p->next;
		free(p);
	}
	else if(p->next != NULL)
	{
		Heap = Heap->next;
		free(p);
	}
	else
	{
		Heap = NULL;
		free(p);
	}
  }

  //return pointer to mem_rec
  return new_rec;
}



