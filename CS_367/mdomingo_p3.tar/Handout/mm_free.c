//Author: Marcus Domingo G#: G00987958
//Last Modified: 11/29/16

#include <stdlib.h>

#include "memory.h"

extern mem_ptr Heap;


void mm_free(mem_ptr m) {
  /* Input: pointer to a mem_rec 
     Output:  None
        You must coalesce this block with adjacent blocks if appropriate. 
        If the input pointer is null, call error_msg(2) and return 
  */

  //if pointer is null call error_msg(2)
  if(m == NULL)
  {
  	error_msg(2);
	return;
  }

  mem_ptr p = Heap;
  mem_ptr q = NULL;

  //search for spot where m address fits in order in the linked list of free blocks
  while((p != NULL) && (p->address < m->address))
  {
	q = p;
	p = p->next;
  }

  //insert m into the linked list of free blocks
  if(Heap == NULL)
  {
  	m->next = m->previous = NULL;
	Heap = m;
  }
  else if(p == NULL)
  {
  	q->next = m;
	m->previous = q;
	m->next = NULL;
  }
  else if(q == NULL)
  {
  	p->previous = m;
	m->next = p;
	Heap = m;
  }
  else
  {
  	q->next = m;
	m->previous = q;
  	m->next = p;
	if(p != NULL)
		p->previous = m;
  }

  p = Heap;

  //coalesce any adjacent free blocks
  //by adding the sizes and using the left blocks address
  while(p != NULL)
  {
  	q = p;

	while(q != NULL)
	{
		if(q->address == (p->address + p->size))
		{
			if(p == Heap)
			{
				q->address = p->address;
				q->size = p->size + q->size;
				q->previous = NULL;
				Heap = q;
			}
			else
			{
				q->address = p->address;
				q->size = p->size + q->size;
				p->previous->next = q;
				q->previous = p->previous;
			}

			free(p);
			p = q;
		}

		q = q->next;
	}

	p = p->next;
  }

  //return from mm_free;
  return;
}
