//Author: Marcus Domingo G#: G00987958
//Last Modified: 11/29/16

#include <stdio.h>
#include <stdlib.h>

#include "memory.h"

extern mem_ptr Heap;


mem_ptr mm_realloc(mem_ptr m, int size) {
  /* Input: pointer to a mem_rec, new size of the block needed
     Output: 
       If the input pointer is null, call error_msg(2) and return

       Return a pointer to a mem_rec of the appropriate size (new_size).
       This block should be chosen as follows:
          if the new size is less than the current size of the block, 
            use the current block after moving the excess back to the free
            list
          if the new block size is larger than the current size, 
            first see if there is enough space after the current block
              to expand.  
            If this will not work, you will need to free the current block
              and find a location for this larger block using first-fit.
       If there is nowhere to place a block of the given size, print
          call error_msg(1) and return a NULL pointer
  */

   int new_size = ALIGN(size);

   //if pointer is null call error_msg(2)
   if(m == NULL)
   {
   	error_msg(2);
	return;
   }

   mem_ptr new_alloc = NULL;
   new_alloc = (mem_ptr)malloc(sizeof(mem_rec));

   //if the new size is smaller than current block size
   //adjust the block and release any extra space to free blocks
   if(new_size < m->size)
   {
   	new_alloc->address = m->address;
	new_alloc->size = new_size;
	m->address = m->address + new_size;
	m->size = m->size - new_size;
	mm_free(m);

	return new_alloc;
   }

   //if the new size is bigger than the current block size
   else if(new_size > m->size)
   {
   	mem_ptr p = Heap;
	int needed_size = new_size - m->size;

	//search free blocks
	//for a free block that is right-adjacent to the current block
   	while(p != NULL)
	{
		if(p->address == (m->address + m->size))
		{
			break;
		}

		p = p->next;
	}

	//if no free block is found or size doesn't fit
	//release current block and use first-fit for new size
	if(p == NULL || p->size < needed_size)
	{
		free(new_alloc);
		mm_free(m);
		return mm_malloc(new_size);
	}

	//if the size fits
	if(p->size >= needed_size)
	{
		//set size and address for the reallocation
		new_alloc->address = m->address;
		new_alloc->size = new_size;

		//adjust free block
		p->address = p->address + needed_size;
		p->size = p->size - needed_size;

		free(m);

		//if the adjusted free block size is 0 remove it
		if(p->size == 0)
		{
			if(p != Heap)
			{
				if(p->next != NULL)
					p->next->previous = p->previous;
				p->previous->next = p->next;
				free(p);
			}
			else if(p->next != NULL)
			{
				Heap = Heap->next;
				free(p);
			}
			else
			{
				Heap = NULL;
				free(p);
			}
		}

		//return pointer to the reallocation
		return new_alloc;
	}
   }
   //if the new_size = m->size
   //return m
   else
   {
   	free(new_alloc);
   	return m;
   }

   return NULL;
}



